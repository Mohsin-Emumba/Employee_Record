import React from "react";

const About = () => {
    return (
        <div className="container" >
            <div className="w-75 mx-auto shadow p-5" style={{ backgroundColor: "#6d7b74" }}>
                <div className="py-4">
                    <h1>About Page</h1>
                    <h3 className="lead">
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Cumque rerum
                        hic ab veniam reiciendis cum repudiandae, voluptate explicabo nesciunt
                        nam accusantium? Soluta cupiditate, accusamus commodi praesentium
                        laborum dolorum libero maiores!
                    </h3>

                    <h3 className="lead" >
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Cumque rerum
                        hic ab veniam reiciendis cum repudiandae, voluptate explicabo nesciunt
                        nam accusantium? Soluta cupiditate, accusamus commodi praesentium
                        laborum dolorum libero maiores!
                    </h3>
                    <h3 className="lead ">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Cumque rerum
                        hic ab veniam reiciendis cum repudiandae, voluptate explicabo nesciunt
                        nam accusantium? Soluta cupiditate, accusamus commodi praesentium
                        laborum dolorum libero maiores!</h3>
                </div>
            </div>
        </div>
    );
};

export default About;